document.addEventListener('DOMContentLoaded', () => {
    console.log("BAI Framework JS Loaded!");

    // Example: Add a class to all cards after a delay
    const cards = document.querySelectorAll('.card');
    if (cards.length > 0) {
        setTimeout(() => {
            cards.forEach(card => {
                card.style.borderColor = '#007bff';
            });
            console.log('Cards highlighted.');
        }, 1000);
    }
});