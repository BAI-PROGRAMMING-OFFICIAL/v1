CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO users (username, password) VALUES ('admin', '$2b$12$EixZaYVK103s9o3vPIkYQ.fXoQYJ0vC9U.0f3jJ4g3.Y9jZ4v.H5O');
-- The default password for 'admin' is 'password'